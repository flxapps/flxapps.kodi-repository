Repository for Kodi containing the <a href="https://github.com/flxapps/plugin.video.mubi">MUBI Plugin</a> (mainly for private use).
